`ifndef SEQUENCE_SV
`define SEQUENCE_SV

`timescale 1ns / 1ps
`include "uvm_macros.svh"
import uvm_pkg::*;
`include "junbro_ram_seq_item.sv"

class junbro_base_seq extends uvm_sequence #(junbro_seq_item);
    `uvm_object_utils(junbro_base_seq);
    int num_loop = 0;

    function new(string name = "junbro_base_seq");
        super.new(name);
    endfunction  //new()

    task defin_func(bit [7:0] addr, bit [31:0] data);
        junbro_seq_item item;
        item = junbro_seq_item::type_id::create("item");
        start_item(item);
        finish_item(item);
    endtask


    virtual task body();
    endtask

endclass

class junbro_write_read_seq extends junbro_base_seq;
    `uvm_object_utils(junbro_write_read_seq);
    int num_loop = 0;
    bit [7:0] addr;
    bit [31:0] wdata, rdata;

    function new(string name = "junbro_write_read_seq");
        super.new(name);
    endfunction  //new()

    virtual task body();
        junbro_seq_item item = junbro_seq_item::type_id::create("item");
        defin_func(addr, wdata);
    endtask

endclass

`endif
