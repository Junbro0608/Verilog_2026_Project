`timescale 1ns / 1ps
`include "uvm_macros.svh"
import uvm_pkg::*;

`include "junbro_interface.sv"
`include "junbro_seq_item.sv"
`include "junbro_sequence.sv"
`include "junbro_driver.sv"
`include "junbro_monitor.sv"
`include "junbro_agent.sv"
`include "junbro_scoreboard.sv"
`include "junbro_coverage.sv"
`include "junbro_env.sv"
`include "junbro_test.sv"

module tb_apb ();
    logic clk;
    logic rst_n;
    initial pclk = 0;
    always #5 pclk = ~pclk;

    junbro_if vif (
    );

    //DUT

    initial begin
        clk = 0;
        rst_n = 0;
        repeat (5) @(posedge pclk);
        rst_n = 1;
    end
    
    initial begin
        uvm_config_db#(virtual junbro_if)::set(null, "*", "vif", vif);
        run_test();
    end

    initial begin
        $timeformat(-9, 3, " ns");
        $fsdbDumpfile("novas.fsdb");
        $fsdbDumpvars(0, tb_junbro, "+all");
    end
endmodule
